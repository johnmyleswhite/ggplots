#!/bin/bash

rm ggplots_*.tar.gz
rm -rf ggplots.Rcheck
R CMD BUILD .
R CMD CHECK ggplots_*.tar.gz
R CMD INSTALL ggplots_*.tar.gz
